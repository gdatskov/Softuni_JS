## NPM 
 1. `npm init -y`
 2. Define start script and run with `npm start`
 3. Install new package `npm i calculator`
 4. Restore installed packages `npm i`
 5. 

## Modules
 1. Core / nodejs modules
 2. Internal / custom
 3. External / vendor
