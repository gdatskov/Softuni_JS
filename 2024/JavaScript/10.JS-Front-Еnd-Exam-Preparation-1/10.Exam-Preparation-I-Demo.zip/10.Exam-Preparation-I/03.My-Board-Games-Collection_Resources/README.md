
1. `npm i`
2. Start index.html with live server (optional)
3. `npm start` this will be needed for tests
4. Open new terminal and execute `cd server` and `node server.js` and leave the terminal 
5. run tests with `npm test`

Note:
 * Don't forget to lear inputs earler (before request)
